<?php
$conn = mysqli_connect("localhost","database@9440672439","","assignment3");
 if($conn)
 {
     echo "";
 }
 else{
     echo "error";
 }
?>